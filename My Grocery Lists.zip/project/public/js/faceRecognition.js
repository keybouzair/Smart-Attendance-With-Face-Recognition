// Face recognition client-side implementation
class FaceRecognition {
  constructor() {
    this.video = null;
    this.canvas = null;
    this.ctx = null;
    this.faceApiLoaded = false;
    this.faceMatcher = null;
    this.livenessCheckActive = false;
    this.maskDetectionEnabled = true;
    this.socket = null;
  }
  
  /**
   * Initialize face recognition
   * @param {HTMLVideoElement} videoElement - Video element
   * @param {HTMLCanvasElement} canvasElement - Canvas element
   * @param {Object} options - Configuration options
   */
  async initialize(videoElement, canvasElement, options = {}) {
    this.video = videoElement;
    this.canvas = canvasElement;
    this.ctx = this.canvas.getContext('2d');
    this.options = {
      matchThreshold: 0.6,
      livenessCheckInterval: 3000,
      maskDetectionEnabled: true,
      ...options
    };
    
    this.socket = io();
    
    try {
      // Load face-api.js models
      await Promise.all([
        faceapi.nets.ssdMobilenetv1.loadFromUri('/models'),
        faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
        faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
        faceapi.nets.ageGenderNet.loadFromUri('/models'),
        faceapi.nets.faceExpressionNet.loadFromUri('/models')
      ]);
      
      if (this.options.maskDetectionEnabled) {
        // Load mask detection model
        // This would be implemented using TensorFlow.js or similar
      }
      
      this.faceApiLoaded = true;
      console.log('Face recognition models loaded');
      
      // Initialize webcam
      await this.startVideo();
      
      // Load labeled face descriptors (user face data)
      await this.loadFaceData();
      
      // Start face recognition
      this.startFaceRecognition();
      
      return true;
    } catch (error) {
      console.error('Error initializing face recognition:', error);
      return false;
    }
  }
  
  /**
   * Start webcam video
   */
  async startVideo() {
    try {
      const constraints = {
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: 'user'
        }
      };
      
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      this.video.srcObject = stream;
      
      return new Promise((resolve) => {
        this.video.onloadedmetadata = () => {
          this.canvas.width = this.video.videoWidth;
          this.canvas.height = this.video.videoHeight;
          resolve();
        };
      });
    } catch (error) {
      console.error('Error starting video:', error);
      throw error;
    }
  }
  
  /**
   * Load face data from server
   */
  async loadFaceData() {
    try {
      const response = await fetch('/api/users/face-data');
      const data = await response.json();
      
      if (!data.success || !data.faceData || data.faceData.length === 0) {
        console.warn('No face data available');
        return;
      }
      
      const labeledDescriptors = data.faceData.map(item => {
        // Convert base64 to Float32Array descriptors
        const descriptors = [this.base64ToFloat32Array(item.descriptor)];
        return new faceapi.LabeledFaceDescriptors(item.userId, descriptors);
      });
      
      this.faceMatcher = new faceapi.FaceMatcher(labeledDescriptors, this.options.matchThreshold);
      console.log('Face data loaded successfully');
    } catch (error) {
      console.error('Error loading face data:', error);
    }
  }
  
  /**
   * Start face recognition process
   */
  startFaceRecognition() {
    if (!this.faceApiLoaded || !this.video || !this.canvas) {
      console.error('Face recognition not initialized');
      return;
    }
    
    const recognitionInterval = setInterval(async () => {
      if (!this.video.paused && !this.video.ended) {
        // Detect faces
        const detections = await faceapi.detectAllFaces(this.video)
          .withFaceLandmarks()
          .withFaceDescriptors();
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw video frame
        this.ctx.drawImage(this.video, 0, 0, this.canvas.width, this.canvas.height);
        
        // Process detections
        if (detections.length > 0) {
          // Perform liveness check if enabled
          if (this.options.livenessCheckEnabled && !this.livenessCheckActive) {
            this.performLivenessCheck();
          }
          
          // Check for mask if enabled
          let maskDetected = false;
          if (this.options.maskDetectionEnabled) {
            maskDetected = await this.detectMask(detections[0]);
          }
          
          // Recognize faces
          if (this.faceMatcher) {
            for (const detection of detections) {
              const descriptor = detection.descriptor;
              const match = this.faceMatcher.findBestMatch(descriptor);
              
              // Draw face box
              const box = detection.detection.box;
              const drawBox = new faceapi.draw.DrawBox(box, {
                label: match.toString(),
                boxColor: match.distance < this.options.matchThreshold ? 'green' : 'red'
              });
              drawBox.draw(this.canvas);
              
              // If face is recognized with high confidence
              if (match.distance < this.options.matchThreshold && !match.toString().includes('unknown')) {
                const userId = match.label;
                
                // Mark attendance
                this.markAttendance(userId, maskDetected);
                
                // Stop recognition after successful match
                clearInterval(recognitionInterval);
                this.showSuccessMessage(`Welcome, ${userId}`);
                return;
              }
            }
          }
        }
      }
    }, 100);
  }
  
  /**
   * Perform liveness check to prevent spoofing
   */
  performLivenessCheck() {
    this.livenessCheckActive = true;
    
    // Simple blink detection
    const blinkDetection = async () => {
      const frames = [];
      
      // Capture multiple frames
      for (let i = 0; i < 10; i++) {
        await new Promise(resolve => setTimeout(resolve, 200));
        
        const detections = await faceapi.detectAllFaces(this.video)
          .withFaceLandmarks();
        
        if (detections.length > 0) {
          frames.push(detections[0]);
        }
      }
      
      // Analyze eye aspect ratios across frames to detect blinks
      let blinkDetected = false;
      let previousEAR = 1.0;
      
      for (let i = 1; i < frames.length; i++) {
        if (!frames[i] || !frames[i].landmarks) continue;
        
        const landmarks = frames[i].landmarks.positions;
        const leftEye = this.getEyePoints(landmarks, true);
        const rightEye = this.getEyePoints(landmarks, false);
        
        const leftEAR = this.calculateEAR(leftEye);
        const rightEAR = this.calculateEAR(rightEye);
        const ear = (leftEAR + rightEAR) / 2.0;
        
        // Detect significant drop and recovery in EAR (Eye Aspect Ratio)
        if (previousEAR > 0.3 && ear < 0.2 && previousEAR - ear > 0.1) {
          blinkDetected = true;
        }
        
        previousEAR = ear;
      }
      
      if (blinkDetected) {
        console.log('Liveness check passed: Blink detected');
      } else {
        console.log('Liveness check failed: No blink detected');
      }
      
      this.livenessCheckActive = false;
      return blinkDetected;
    };
    
    blinkDetection();
  }
  
  /**
   * Get eye landmark points
   * @param {Array} landmarks - Face landmarks
   * @param {Boolean} isLeft - Whether it's the left eye
   * @returns {Array} - Eye landmark points
   */
  getEyePoints(landmarks, isLeft) {
    // face-api.js uses different indices, this is just a placeholder
    // Real implementation would use the correct landmark indices
    const start = isLeft ? 36 : 42;
    const points = [];
    
    for (let i = 0; i < 6; i++) {
      points.push(landmarks[start + i]);
    }
    
    return points;
  }
  
  /**
   * Calculate Eye Aspect Ratio (EAR)
   * @param {Array} eye - Eye landmark points
   * @returns {Number} - EAR value
   */
  calculateEAR(eye) {
    // Calculate euclidean distance between points
    const dist = (p1, p2) => {
      return Math.sqrt(Math.pow(p2.x - p1.x, 2) + Math.pow(p2.y - p1.y, 2));
    };
    
    // Vertical distances
    const v1 = dist(eye[1], eye[5]);
    const v2 = dist(eye[2], eye[4]);
    
    // Horizontal distance
    const h = dist(eye[0], eye[3]);
    
    // EAR formula
    return (v1 + v2) / (2.0 * h);
  }
  
  /**
   * Detect if person is wearing a mask
   * @param {Object} detection - Face detection
   * @returns {Promise<Boolean>} - True if mask detected
   */
  async detectMask(detection) {
    // This would be implemented using a trained model
    // Simplified placeholder for demonstration
    return false;
  }
  
  /**
   * Mark attendance on the server
   * @param {String} userId - User ID
   * @param {Boolean} maskDetected - Whether mask was detected
   */
  async markAttendance(userId, maskDetected) {
    try {
      // Get geolocation if available
      let location = null;
      
      if (navigator.geolocation) {
        location = await new Promise((resolve) => {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              resolve({
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
              });
            },
            () => resolve(null)
          );
        });
      }
      
      // Send attendance data to server
      const response = await fetch('/api/attendance/mark-face', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          userId,
          maskDetected,
          location
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        this.playSuccessSound();
        return true;
      } else {
        console.error('Error marking attendance:', data.error);
        return false;
      }
    } catch (error) {
      console.error('Error marking attendance:', error);
      return false;
    }
  }
  
  /**
   * Play success sound
   */
  playSuccessSound() {
    const audio = new Audio('/sounds/success.mp3');
    audio.play();
  }
  
  /**
   * Show success message
   * @param {String} message - Success message
   */
  showSuccessMessage(message) {
    // This would be implemented in the UI
    console.log(`Success: ${message}`);
  }
  
  /**
   * Convert base64 string to Float32Array
   * @param {String} base64 - Base64 encoded string
   * @returns {Float32Array} - Float32Array
   */
  base64ToFloat32Array(base64) {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    
    return new Float32Array(bytes.buffer);
  }
}

// Make available globally
window.FaceRecognition = new FaceRecognition();