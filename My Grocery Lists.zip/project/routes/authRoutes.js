const express = require('express');
const bcrypt = require('bcrypt');
const User = require('../models/User');
const { logLogin, logLogout } = require('../middleware/authMiddleware');
const { logger } = require('../server');
const router = express.Router();

// Login route
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    
    // Find user by email
    const user = await User.findOne({ email });
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Check password
    const isMatch = await user.comparePassword(password);
    
    if (!isMatch) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    // Create session
    req.session.user = {
      _id: user._id,
      name: user.name,
      email: user.email,
      role: user.role
    };
    
    // Log login activity
    await logLogin(user._id, req);
    
    return res.status(200).json({
      success: true,
      user: {
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    logger.error('Login error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Logout route
router.get('/logout', async (req, res) => {
  try {
    // Log logout activity
    await logLogout(req);
    
    // Destroy session
    req.session.destroy(err => {
      if (err) {
        return res.status(500).json({ error: 'Error logging out' });
      }
      
      res.clearCookie('connect.sid');
      return res.status(200).json({ success: true });
    });
  } catch (error) {
    logger.error('Logout error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Register route (admin only can create users in production)
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, role, studentId } = req.body;
    
    // In production, only admins can create users
    if (process.env.NODE_ENV === 'production' && 
        (!req.session.user || req.session.user.role !== 'admin')) {
      return res.status(403).json({ error: 'Admin access required' });
    }
    
    // Check if user already exists
    const existingUser = await User.findOne({ email });
    
    if (existingUser) {
      return res.status(400).json({ error: 'User already exists' });
    }
    
    // Create new user
    const user = new User({
      name,
      email,
      password,
      role: role || 'student',
      studentId: studentId || null
    });
    
    await user.save();
    
    return res.status(201).json({
      success: true,
      user: {
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (error) {
    logger.error('Registration error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Change password
router.post('/change-password', async (req, res) => {
  try {
    if (!req.session.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    
    const { currentPassword, newPassword } = req.body;
    
    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Current and new passwords are required' });
    }
    
    // Find user
    const user = await User.findById(req.session.user._id);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Check current password
    const isMatch = await user.comparePassword(currentPassword);
    
    if (!isMatch) {
      return res.status(401).json({ error: 'Current password is incorrect' });
    }
    
    // Update password
    user.password = newPassword;
    await user.save();
    
    return res.status(200).json({ success: true });
  } catch (error) {
    logger.error('Change password error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;