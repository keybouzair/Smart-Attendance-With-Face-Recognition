const express = require('express');
const User = require('../models/User');
const Attendance = require('../models/Attendance');
const { logger } = require('../server');
const { checkTeacherOrAdmin } = require('../middleware/authMiddleware');
const router = express.Router();

// Get attendance statistics
router.get('/statistics', checkTeacherOrAdmin, async (req, res) => {
  try {
    // Get date range
    const { startDate, endDate } = req.query;
    
    const query = {};
    
    if (startDate || endDate) {
      query.date = {};
      
      if (startDate) {
        query.date.$gte = new Date(startDate);
      }
      
      if (endDate) {
        const endDateObj = new Date(endDate);
        endDateObj.setHours(23, 59, 59, 999);
        query.date.$lte = endDateObj;
      }
    } else {
      // Default to current month
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
      
      query.date = {
        $gte: startOfMonth,
        $lte: endOfMonth
      };
    }
    
    // Get attendance records
    const attendanceRecords = await Attendance.find(query);
    
    // Get total users
    const totalUsers = await User.countDocuments({ role: 'student' });
    
    // Calculate statistics
    const totalRecords = attendanceRecords.length;
    const presentCount = attendanceRecords.filter(a => a.status === 'present').length;
    const absentCount = attendanceRecords.filter(a => a.status === 'absent').length;
    const lateCount = attendanceRecords.filter(a => a.status === 'late').length;
    
    // Calculate attendance percentage
    const attendancePercentage = totalRecords > 0
      ? Math.round((presentCount / totalRecords) * 100)
      : 0;
    
    // Group by verification method
    const verificationMethods = attendanceRecords.reduce((acc, record) => {
      acc[record.verificationMethod] = (acc[record.verificationMethod] || 0) + 1;
      return acc;
    }, {});
    
    return res.status(200).json({
      success: true,
      statistics: {
        totalUsers,
        totalRecords,
        presentCount,
        absentCount,
        lateCount,
        attendancePercentage,
        verificationMethods
      }
    });
  } catch (error) {
    logger.error('Get statistics error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Get attendance by date
router.get('/attendance-by-date', checkTeacherOrAdmin, async (req, res) => {
  try {
    // Get date
    const { date } = req.query;
    
    if (!date) {
      return res.status(400).json({ error: 'Date is required' });
    }
    
    const selectedDate = new Date(date);
    selectedDate.setHours(0, 0, 0, 0);
    
    const nextDay = new Date(selectedDate);
    nextDay.setDate(nextDay.getDate() + 1);
    
    // Get attendance records for the date
    const attendanceRecords = await Attendance.find({
      date: {
        $gte: selectedDate,
        $lt: nextDay
      }
    }).populate('user', 'name email studentId');
    
    // Get all students
    const students = await User.find({ role: 'student' })
      .select('name email studentId');
    
    // Map attendance status for each student
    const attendanceData = students.map(student => {
      const record = attendanceRecords.find(a => 
        a.user._id.toString() === student._id.toString()
      );
      
      return {
        student: {
          _id: student._id,
          name: student.name,
          email: student.email,
          studentId: student.studentId
        },
        attendance: record ? {
          status: record.status,
          checkInTime: record.checkInTime,
          checkOutTime: record.checkOutTime,
          verificationMethod: record.verificationMethod,
          notes: record.notes
        } : null
      };
    });
    
    return res.status(200).json({
      success: true,
      date: selectedDate,
      attendanceData
    });
  } catch (error) {
    logger.error('Get attendance by date error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Get attendance by student
router.get('/attendance-by-student/:studentId', checkTeacherOrAdmin, async (req, res) => {
  try {
    const { studentId } = req.params;
    const { startDate, endDate } = req.query;
    
    // Find student
    const student = await User.findOne({
      $or: [
        { _id: studentId },
        { studentId }
      ]
    }).select('name email studentId');
    
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }
    
    const query = { user: student._id };
    
    if (startDate || endDate) {
      query.date = {};
      
      if (startDate) {
        query.date.$gte = new Date(startDate);
      }
      
      if (endDate) {
        const endDateObj = new Date(endDate);
        endDateObj.setHours(23, 59, 59, 999);
        query.date.$lte = endDateObj;
      }
    }
    
    // Get attendance records
    const attendanceRecords = await Attendance.find(query)
      .sort({ date: -1 });
    
    // Calculate statistics
    const totalDays = attendanceRecords.length;
    const presentDays = attendanceRecords.filter(a => a.status === 'present').length;
    const absentDays = attendanceRecords.filter(a => a.status === 'absent').length;
    const lateDays = attendanceRecords.filter(a => a.status === 'late').length;
    
    // Calculate attendance percentage
    const attendancePercentage = totalDays > 0
      ? Math.round((presentDays / totalDays) * 100)
      : 0;
    
    return res.status(200).json({
      success: true,
      student,
      attendanceRecords,
      statistics: {
        totalDays,
        presentDays,
        absentDays,
        lateDays,
        attendancePercentage
      }
    });
  } catch (error) {
    logger.error('Get attendance by student error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Get monthly attendance overview
router.get('/monthly-overview', checkTeacherOrAdmin, async (req, res) => {
  try {
    const { year, month } = req.query;
    
    // Validate year and month
    const selectedYear = parseInt(year) || new Date().getFullYear();
    const selectedMonth = parseInt(month) || new Date().getMonth() + 1;
    
    // Get start and end of month
    const startDate = new Date(selectedYear, selectedMonth - 1, 1);
    const endDate = new Date(selectedYear, selectedMonth, 0, 23, 59, 59, 999);
    
    // Get all attendance records for the month
    const attendanceRecords = await Attendance.find({
      date: {
        $gte: startDate,
        $lte: endDate
      }
    }).populate('user', 'name studentId');
    
    // Group records by date
    const groupedByDate = {};
    
    attendanceRecords.forEach(record => {
      const dateStr = record.date.toISOString().split('T')[0];
      
      if (!groupedByDate[dateStr]) {
        groupedByDate[dateStr] = {
          date: dateStr,
          total: 0,
          present: 0,
          absent: 0,
          late: 0
        };
      }
      
      groupedByDate[dateStr].total++;
      
      if (record.status === 'present') {
        groupedByDate[dateStr].present++;
      } else if (record.status === 'absent') {
        groupedByDate[dateStr].absent++;
      } else if (record.status === 'late') {
        groupedByDate[dateStr].late++;
      }
    });
    
    // Convert to array
    const dailyAttendance = Object.values(groupedByDate).sort((a, b) => 
      new Date(a.date) - new Date(b.date)
    );
    
    return res.status(200).json({
      success: true,
      year: selectedYear,
      month: selectedMonth,
      dailyAttendance
    });
  } catch (error) {
    logger.error('Get monthly overview error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;