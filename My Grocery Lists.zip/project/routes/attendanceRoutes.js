const express = require('express');
const QRCode = require('qrcode');
const { v4: uuidv4 } = require('uuid');
const User = require('../models/User');
const Attendance = require('../models/Attendance');
const Notification = require('../models/Notification');
const { checkTeacherOrAdmin } = require('../middleware/authMiddleware');
const { logger } = require('../server');
const router = express.Router();

// Mark attendance via face recognition
router.post('/mark-face', async (req, res) => {
  try {
    const { userId, maskDetected, location } = req.body;
    
    // Find user
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Get current date (without time)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Check if attendance already marked for today
    const existingAttendance = await Attendance.findOne({
      user: userId,
      date: {
        $gte: today,
        $lt: new Date(today.getTime() + 24 * 60 * 60 * 1000)
      }
    });
    
    if (existingAttendance) {
      // Update check-out time if already checked in
      if (existingAttendance.checkInTime && !existingAttendance.checkOutTime) {
        existingAttendance.checkOutTime = new Date();
        await existingAttendance.save();
        
        return res.status(200).json({
          success: true,
          message: 'Check-out recorded successfully',
          attendance: existingAttendance
        });
      }
      
      return res.status(400).json({
        error: 'Attendance already marked for today',
        attendance: existingAttendance
      });
    }
    
    // Create new attendance record
    const attendance = new Attendance({
      user: userId,
      date: new Date(),
      status: 'present',
      verificationMethod: 'face',
      maskDetected: maskDetected || false,
      checkInTime: new Date(),
      location: location ? {
        type: 'Point',
        coordinates: [location.longitude, location.latitude]
      } : undefined
    });
    
    await attendance.save();
    
    // Emit socket event for real-time updates
    res.locals.io.emit('attendance_update', {
      user: user.name,
      time: attendance.checkInTime,
      status: 'present'
    });
    
    // Create notification
    await Notification.create({
      recipient: userId,
      title: 'Attendance Marked',
      message: `Your attendance has been marked for ${new Date().toLocaleDateString()}`,
      type: 'system',
      status: 'sent'
    });
    
    return res.status(200).json({
      success: true,
      message: 'Attendance marked successfully',
      attendance
    });
  } catch (error) {
    logger.error('Mark attendance error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Generate QR code for attendance
router.get('/generate-qr/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Find user
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Generate unique code
    const qrData = {
      userId: user._id.toString(),
      timestamp: new Date().getTime(),
      token: uuidv4()
    };
    
    // Save QR code to user
    user.qrCode = JSON.stringify(qrData);
    await user.save();
    
    // Generate QR code
    const qrCode = await QRCode.toDataURL(JSON.stringify(qrData));
    
    return res.status(200).json({
      success: true,
      qrCode
    });
  } catch (error) {
    logger.error('Generate QR error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Mark attendance via QR code
router.post('/mark-qr', async (req, res) => {
  try {
    const { qrData, location } = req.body;
    
    if (!qrData) {
      return res.status(400).json({ error: 'QR data is required' });
    }
    
    // Parse QR data
    const parsedData = JSON.parse(qrData);
    
    if (!parsedData.userId || !parsedData.timestamp || !parsedData.token) {
      return res.status(400).json({ error: 'Invalid QR code' });
    }
    
    // Find user
    const user = await User.findById(parsedData.userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Verify QR code
    if (!user.qrCode || user.qrCode !== qrData) {
      return res.status(401).json({ error: 'Invalid or expired QR code' });
    }
    
    // Check if QR code is expired (valid for 5 minutes)
    const qrTimestamp = parsedData.timestamp;
    const currentTime = new Date().getTime();
    
    if (currentTime - qrTimestamp > 5 * 60 * 1000) {
      return res.status(401).json({ error: 'QR code has expired' });
    }
    
    // Get current date (without time)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Check if attendance already marked for today
    const existingAttendance = await Attendance.findOne({
      user: parsedData.userId,
      date: {
        $gte: today,
        $lt: new Date(today.getTime() + 24 * 60 * 60 * 1000)
      }
    });
    
    if (existingAttendance) {
      // Update check-out time if already checked in
      if (existingAttendance.checkInTime && !existingAttendance.checkOutTime) {
        existingAttendance.checkOutTime = new Date();
        await existingAttendance.save();
        
        return res.status(200).json({
          success: true,
          message: 'Check-out recorded successfully',
          attendance: existingAttendance
        });
      }
      
      return res.status(400).json({
        error: 'Attendance already marked for today',
        attendance: existingAttendance
      });
    }
    
    // Create new attendance record
    const attendance = new Attendance({
      user: parsedData.userId,
      date: new Date(),
      status: 'present',
      verificationMethod: 'qr',
      checkInTime: new Date(),
      location: location ? {
        type: 'Point',
        coordinates: [location.longitude, location.latitude]
      } : undefined
    });
    
    await attendance.save();
    
    // Emit socket event for real-time updates
    res.locals.io.emit('attendance_update', {
      user: user.name,
      time: attendance.checkInTime,
      status: 'present'
    });
    
    // Create notification
    await Notification.create({
      recipient: parsedData.userId,
      title: 'Attendance Marked',
      message: `Your attendance has been marked for ${new Date().toLocaleDateString()}`,
      type: 'system',
      status: 'sent'
    });
    
    // Clear QR code after use
    user.qrCode = null;
    await user.save();
    
    return res.status(200).json({
      success: true,
      message: 'Attendance marked successfully',
      attendance
    });
  } catch (error) {
    logger.error('Mark QR attendance error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Mark attendance manually (for teachers/admins)
router.post('/mark-manual', checkTeacherOrAdmin, async (req, res) => {
  try {
    const { userId, status, notes } = req.body;
    
    if (!userId || !status) {
      return res.status(400).json({ error: 'User ID and status are required' });
    }
    
    // Find user
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Get current date (without time)
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // Check if attendance already marked for today
    let attendance = await Attendance.findOne({
      user: userId,
      date: {
        $gte: today,
        $lt: new Date(today.getTime() + 24 * 60 * 60 * 1000)
      }
    });
    
    if (attendance) {
      // Update existing attendance
      attendance.status = status;
      attendance.notes = notes || '';
      attendance.markedBy = req.session.user._id;
      
      if (status === 'present' && !attendance.checkInTime) {
        attendance.checkInTime = new Date();
      }
    } else {
      // Create new attendance record
      attendance = new Attendance({
        user: userId,
        date: new Date(),
        status,
        verificationMethod: 'manual',
        notes: notes || '',
        markedBy: req.session.user._id,
        checkInTime: status === 'present' ? new Date() : null
      });
    }
    
    await attendance.save();
    
    // Emit socket event for real-time updates
    res.locals.io.emit('attendance_update', {
      user: user.name,
      time: new Date(),
      status: attendance.status,
      markedBy: req.session.user.name
    });
    
    // Create notification
    await Notification.create({
      recipient: userId,
      title: 'Attendance Updated',
      message: `Your attendance has been marked as ${status} for ${new Date().toLocaleDateString()}`,
      type: 'system',
      status: 'sent'
    });
    
    return res.status(200).json({
      success: true,
      message: 'Attendance marked successfully',
      attendance
    });
  } catch (error) {
    logger.error('Mark manual attendance error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Get attendance for current user
router.get('/my-attendance', async (req, res) => {
  try {
    const userId = req.session.user._id;
    
    // Get date range from query parameters
    const { startDate, endDate } = req.query;
    
    const query = { user: userId };
    
    if (startDate || endDate) {
      query.date = {};
      
      if (startDate) {
        query.date.$gte = new Date(startDate);
      }
      
      if (endDate) {
        const endDateObj = new Date(endDate);
        endDateObj.setHours(23, 59, 59, 999);
        query.date.$lte = endDateObj;
      }
    }
    
    // Get attendance records
    const attendance = await Attendance.find(query)
      .sort({ date: -1 })
      .limit(30);
    
    return res.status(200).json({
      success: true,
      attendance
    });
  } catch (error) {
    logger.error('Get attendance error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Get attendance statistics for current user
router.get('/my-statistics', async (req, res) => {
  try {
    const userId = req.session.user._id;
    
    // Get current month range
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
    
    // Get attendance records for current month
    const monthlyAttendance = await Attendance.find({
      user: userId,
      date: {
        $gte: startOfMonth,
        $lte: endOfMonth
      }
    });
    
    // Calculate statistics
    const totalDays = monthlyAttendance.length;
    const presentDays = monthlyAttendance.filter(a => a.status === 'present').length;
    const absentDays = monthlyAttendance.filter(a => a.status === 'absent').length;
    const lateDays = monthlyAttendance.filter(a => a.status === 'late').length;
    
    // Calculate attendance percentage
    const attendancePercentage = totalDays > 0
      ? Math.round((presentDays / totalDays) * 100)
      : 0;
    
    return res.status(200).json({
      success: true,
      statistics: {
        totalDays,
        presentDays,
        absentDays,
        lateDays,
        attendancePercentage
      }
    });
  } catch (error) {
    logger.error('Get statistics error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;