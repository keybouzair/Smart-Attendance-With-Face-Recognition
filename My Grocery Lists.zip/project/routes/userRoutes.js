const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const User = require('../models/User');
const { checkAdmin } = require('../middleware/authMiddleware');
const { logger } = require('../server');
const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads');
    
    // Create directory if it doesn't exist
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    // Accept only images
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Get current user profile
router.get('/profile', async (req, res) => {
  try {
    const userId = req.session.user._id;
    
    // Find user without sensitive data
    const user = await User.findById(userId).select('-password -faceData -qrCode');
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    return res.status(200).json({
      success: true,
      user
    });
  } catch (error) {
    logger.error('Get profile error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Update user profile
router.put('/profile', async (req, res) => {
  try {
    const userId = req.session.user._id;
    const { name, email, contactNumber, parentEmail } = req.body;
    
    // Find user
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Check if email is taken by another user
    if (email !== user.email) {
      const existingUser = await User.findOne({ email });
      
      if (existingUser) {
        return res.status(400).json({ error: 'Email is already taken' });
      }
    }
    
    // Update user
    user.name = name || user.name;
    user.email = email || user.email;
    user.contactNumber = contactNumber || user.contactNumber;
    user.parentEmail = parentEmail || user.parentEmail;
    
    await user.save();
    
    return res.status(200).json({
      success: true,
      user: {
        name: user.name,
        email: user.email,
        contactNumber: user.contactNumber,
        parentEmail: user.parentEmail
      }
    });
  } catch (error) {
    logger.error('Update profile error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Upload face data
router.post('/upload-face', upload.single('faceImage'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const userId = req.session.user._id;
    
    // Read file
    const faceData = fs.readFileSync(req.file.path);
    
    // Update user with face data
    await User.findByIdAndUpdate(userId, {
      faceData
    });
    
    // Delete temporary file
    fs.unlinkSync(req.file.path);
    
    return res.status(200).json({
      success: true,
      message: 'Face data uploaded successfully'
    });
  } catch (error) {
    logger.error('Upload face error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Get all users (admin only)
router.get('/all', checkAdmin, async (req, res) => {
  try {
    // Get query parameters
    const { role, search } = req.query;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Build query
    const query = {};
    
    if (role) {
      query.role = role;
    }
    
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
        { studentId: { $regex: search, $options: 'i' } }
      ];
    }
    
    // Get users
    const users = await User.find(query)
      .select('-password -faceData -qrCode')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);
    
    // Get total count
    const total = await User.countDocuments(query);
    
    return res.status(200).json({
      success: true,
      users,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    logger.error('Get all users error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Create user (admin only)
router.post('/', checkAdmin, async (req, res) => {
  try {
    const { name, email, password, role, studentId, contactNumber, parentEmail } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({ 
      $or: [
        { email },
        { studentId }
      ]
    });
    
    if (existingUser) {
      return res.status(400).json({ error: 'User with this email or student ID already exists' });
    }
    
    // Create new user
    const user = new User({
      name,
      email,
      password,
      role: role || 'student',
      studentId,
      contactNumber,
      parentEmail
    });
    
    await user.save();
    
    return res.status(201).json({
      success: true,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        studentId: user.studentId
      }
    });
  } catch (error) {
    logger.error('Create user error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Update user (admin only)
router.put('/:userId', checkAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    const { name, email, role, studentId, contactNumber, parentEmail } = req.body;
    
    // Find user
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Check if email is taken by another user
    if (email && email !== user.email) {
      const existingUser = await User.findOne({ email });
      
      if (existingUser) {
        return res.status(400).json({ error: 'Email is already taken' });
      }
    }
    
    // Check if student ID is taken by another user
    if (studentId && studentId !== user.studentId) {
      const existingUser = await User.findOne({ studentId });
      
      if (existingUser) {
        return res.status(400).json({ error: 'Student ID is already taken' });
      }
    }
    
    // Update user
    if (name) user.name = name;
    if (email) user.email = email;
    if (role) user.role = role;
    if (studentId) user.studentId = studentId;
    if (contactNumber) user.contactNumber = contactNumber;
    if (parentEmail) user.parentEmail = parentEmail;
    
    await user.save();
    
    return res.status(200).json({
      success: true,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        studentId: user.studentId,
        contactNumber: user.contactNumber,
        parentEmail: user.parentEmail
      }
    });
  } catch (error) {
    logger.error('Update user error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Delete user (admin only)
router.delete('/:userId', checkAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    
    // Prevent deleting self
    if (userId === req.session.user._id.toString()) {
      return res.status(400).json({ error: 'You cannot delete your own account' });
    }
    
    // Delete user
    const user = await User.findByIdAndDelete(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    return res.status(200).json({
      success: true,
      message: 'User deleted successfully'
    });
  } catch (error) {
    logger.error('Delete user error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Reset user password (admin only)
router.post('/:userId/reset-password', checkAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    const { newPassword } = req.body;
    
    if (!newPassword) {
      return res.status(400).json({ error: 'New password is required' });
    }
    
    // Find user
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Update password
    user.password = newPassword;
    await user.save();
    
    return res.status(200).json({
      success: true,
      message: 'Password reset successfully'
    });
  } catch (error) {
    logger.error('Reset password error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

router.post('/train-face', upload.array('images', 5), async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: 'No training images provided' });
    }

    const userId = req.session.user._id;

    // Train model with provided images
    await FaceRecognitionService.trainModel(userId, req.files);

    return res.status(200).json({
      success: true,
      message: 'Face recognition model trained successfully'
    });
  } catch (error) {
    logger.error('Train face error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;