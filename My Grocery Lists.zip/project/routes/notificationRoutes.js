const express = require('express');
const nodemailer = require('nodemailer');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { checkTeacherOrAdmin } = require('../middleware/authMiddleware');
const { logger } = require('../server');
const router = express.Router();

// Configure nodemailer
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Send email notification
async function sendEmail(to, subject, message) {
  try {
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to,
      subject,
      html: message
    };
    
    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    logger.error('Email sending error:', error);
    return false;
  }
}

// Get notifications for current user
router.get('/my-notifications', async (req, res) => {
  try {
    const userId = req.session.user._id;
    
    // Get page and limit from query
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    
    // Get notifications
    const notifications = await Notification.find({
      recipient: userId
    })
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);
    
    // Get total count
    const total = await Notification.countDocuments({
      recipient: userId
    });
    
    // Mark notifications as read
    await Notification.updateMany(
      { recipient: userId, status: 'sent' },
      { status: 'read' }
    );
    
    return res.status(200).json({
      success: true,
      notifications,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    logger.error('Get notifications error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Send notification to a user
router.post('/send', checkTeacherOrAdmin, async (req, res) => {
  try {
    const { userId, title, message, type, sendEmail } = req.body;
    
    if (!userId || !title || !message) {
      return res.status(400).json({ error: 'User ID, title, and message are required' });
    }
    
    // Find user
    const user = await User.findById(userId);
    
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    
    // Create notification
    const notification = new Notification({
      recipient: userId,
      title,
      message,
      type: type || 'system',
      status: 'sent'
    });
    
    await notification.save();
    
    // Send email if requested
    if (sendEmail && user.email) {
      const emailSent = await sendEmail(
        user.email,
        title,
        `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0A84FF;">${title}</h2>
          <p>${message}</p>
          <p style="color: #666; font-size: 12px;">
            This is an automated message from the Attendance System.
          </p>
        </div>`
      );
      
      if (!emailSent) {
        notification.status = 'failed';
        await notification.save();
      }
    }
    
    // Emit socket event
    res.locals.io.emit('new_notification', {
      userId,
      notification: {
        title,
        message,
        createdAt: notification.createdAt
      }
    });
    
    return res.status(200).json({
      success: true,
      notification
    });
  } catch (error) {
    logger.error('Send notification error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Send notification to all users
router.post('/send-all', checkTeacherOrAdmin, async (req, res) => {
  try {
    const { title, message, role, sendEmail } = req.body;
    
    if (!title || !message) {
      return res.status(400).json({ error: 'Title and message are required' });
    }
    
    // Find users
    const query = {};
    
    if (role) {
      query.role = role;
    }
    
    const users = await User.find(query);
    
    if (users.length === 0) {
      return res.status(404).json({ error: 'No users found' });
    }
    
    // Create notifications
    const notifications = [];
    
    for (const user of users) {
      const notification = new Notification({
        recipient: user._id,
        title,
        message,
        type: 'system',
        status: 'sent'
      });
      
      await notification.save();
      notifications.push(notification);
      
      // Send email if requested
      if (sendEmail && user.email) {
        const emailSent = await sendEmail(
          user.email,
          title,
          `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #0A84FF;">${title}</h2>
            <p>${message}</p>
            <p style="color: #666; font-size: 12px;">
              This is an automated message from the Attendance System.
            </p>
          </div>`
        );
        
        if (!emailSent) {
          notification.status = 'failed';
          await notification.save();
        }
      }
      
      // Emit socket event
      res.locals.io.emit('new_notification', {
        userId: user._id,
        notification: {
          title,
          message,
          createdAt: notification.createdAt
        }
      });
    }
    
    return res.status(200).json({
      success: true,
      count: notifications.length
    });
  } catch (error) {
    logger.error('Send all notifications error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

// Get all notifications (admin only)
router.get('/all', checkTeacherOrAdmin, async (req, res) => {
  try {
    // Get page and limit from query
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;
    
    // Get notifications
    const notifications = await Notification.find()
      .populate('recipient', 'name email')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit);
    
    // Get total count
    const total = await Notification.countDocuments();
    
    return res.status(200).json({
      success: true,
      notifications,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    logger.error('Get all notifications error:', error);
    return res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;