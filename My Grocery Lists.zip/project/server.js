require('dotenv').config();
const express = require('express');
const session = require('express-session');
const mongoose = require('mongoose');
const path = require('path');
const cors = require('cors');
const socketIo = require('socket.io');
const http = require('http');
const winston = require('winston');

// Import routes
const authRoutes = require('./routes/authRoutes');
const attendanceRoutes = require('./routes/attendanceRoutes');
const userRoutes = require('./routes/userRoutes');
const dashboardRoutes = require('./routes/dashboardRoutes');
const notificationRoutes = require('./routes/notificationRoutes');

// Import middleware
const { checkAuth } = require('./middleware/authMiddleware');
const { logActivity } = require('./middleware/loggingMiddleware');

// Create Express app
const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Configure logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'default_secret_key',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: process.env.NODE_ENV === 'production' }
}));
app.use(logActivity);

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Socket.io connection
io.on('connection', (socket) => {
  logger.info('A user connected');
  
  socket.on('disconnect', () => {
    logger.info('User disconnected');
  });
  
  socket.on('attendance_marked', (data) => {
    io.emit('attendance_update', data);
  });
});

// Set global variables for all routes
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.error = null;
  res.locals.success = null;
  res.locals.io = io;
  next();
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/attendance', checkAuth, attendanceRoutes);
app.use('/api/users', checkAuth, userRoutes);
app.use('/api/dashboard', checkAuth, dashboardRoutes);
app.use('/api/notifications', checkAuth, notificationRoutes);

app.get('/', (req, res) => {
  if (req.session.user) {
    return res.redirect('/dashboard');
  }
  res.render('login');
});

app.get('/dashboard', checkAuth, (req, res) => {
  res.render('dashboard');
});

// MongoDB connection options
const mongoOptions = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
  retryWrites: process.env.MONGODB_RETRY_WRITES === 'true',
  ssl: process.env.MONGODB_SSL === 'true',
  authSource: process.env.MONGODB_AUTH_SOURCE || 'admin',
  user: process.env.MONGODB_USER,
  pass: process.env.MONGODB_PASS
};

// Connect to MongoDB
mongoose.connect(process.env.MONGODB_URI, mongoOptions)
  .then(() => {
    logger.info('Connected to MongoDB');
    
    // Start server
    const PORT = process.env.PORT || 3000;
    server.listen(PORT, () => {
      logger.info(`Server running on port ${PORT}`);
    });
  })
  .catch(err => {
    logger.error('MongoDB connection error:', err);
    process.exit(1);
  });

// Handle unhandled promise rejections
process.on('unhandledRejection', (err) => {
  logger.error('Unhandled Rejection:', err);
});

module.exports = { app, io, logger };