const { logger } = require('../server');
const User = require('../models/User');
const ActivityLog = require('../models/ActivityLog');

// Check if user is authenticated
exports.checkAuth = (req, res, next) => {
  if (!req.session.user) {
    if (req.xhr) {
      return res.status(401).json({ error: 'Authentication required' });
    }
    return res.redirect('/');
  }
  next();
};

// Check if user has admin role
exports.checkAdmin = (req, res, next) => {
  if (!req.session.user || req.session.user.role !== 'admin') {
    if (req.xhr) {
      return res.status(403).json({ error: 'Admin access required' });
    }
    return res.redirect('/dashboard');
  }
  next();
};

// Check if user has teacher or admin role
exports.checkTeacherOrAdmin = (req, res, next) => {
  if (!req.session.user || (req.session.user.role !== 'teacher' && req.session.user.role !== 'admin')) {
    if (req.xhr) {
      return res.status(403).json({ error: 'Teacher or admin access required' });
    }
    return res.redirect('/dashboard');
  }
  next();
};

// Log login activity
exports.logLogin = async (userId, req) => {
  try {
    // Update last login time
    await User.findByIdAndUpdate(userId, {
      lastLogin: new Date()
    });
    
    // Log the activity
    await ActivityLog.create({
      user: userId,
      action: 'login',
      details: { successful: true },
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'] || ''
    });
  } catch (error) {
    logger.error('Error logging login activity:', error);
  }
};

// Log logout activity
exports.logLogout = async (req) => {
  if (!req.session.user) return;
  
  try {
    await ActivityLog.create({
      user: req.session.user._id,
      action: 'logout',
      details: {},
      ipAddress: req.ip,
      userAgent: req.headers['user-agent'] || ''
    });
  } catch (error) {
    logger.error('Error logging logout activity:', error);
  }
};