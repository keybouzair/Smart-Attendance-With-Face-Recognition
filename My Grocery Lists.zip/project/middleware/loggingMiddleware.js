const ActivityLog = require('../models/ActivityLog');
const { logger } = require('../server');

// Log API activities
exports.logActivity = async (req, res, next) => {
  // Skip logging for static files and certain paths
  if (req.path.startsWith('/public') || 
      req.path === '/favicon.ico' || 
      req.path === '/') {
    return next();
  }
  
  const originalSend = res.send;
  
  res.send = function(body) {
    res.body = body;
    originalSend.call(this, body);
  };
  
  res.on('finish', async () => {
    if (!req.session.user) return;
    
    try {
      const logData = {
        user: req.session.user._id,
        action: `${req.method} ${req.path}`,
        details: {
          method: req.method,
          path: req.path,
          statusCode: res.statusCode,
          params: req.params,
          query: req.query,
          // Don't log sensitive information
          body: sanitizeRequestBody(req.body)
        },
        ipAddress: req.ip,
        userAgent: req.headers['user-agent'] || ''
      };
      
      await ActivityLog.create(logData);
    } catch (error) {
      logger.error('Error logging activity:', error);
    }
  });
  
  next();
};

// Sanitize request body to remove sensitive information
function sanitizeRequestBody(body) {
  if (!body) return {};
  
  const sanitized = { ...body };
  
  // Remove sensitive fields
  const sensitiveFields = ['password', 'newPassword', 'confirmPassword', 'token', 'apiKey'];
  
  sensitiveFields.forEach(field => {
    if (sanitized[field]) {
      sanitized[field] = '[REDACTED]';
    }
  });
  
  return sanitized;
}