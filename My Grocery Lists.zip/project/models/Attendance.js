const mongoose = require('mongoose');

const attendanceSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    default: Date.now,
    required: true
  },
  status: {
    type: String,
    enum: ['present', 'absent', 'late'],
    default: 'present'
  },
  verificationMethod: {
    type: String,
    enum: ['face', 'qr', 'hybrid', 'manual'],
    required: true
  },
  location: {
    type: {
      type: String,
      enum: ['Point'],
      default: 'Point'
    },
    coordinates: {
      type: [Number],
      default: [0, 0]
    }
  },
  maskDetected: {
    type: Boolean,
    default: false
  },
  markedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null // Self-marked if null
  },
  notes: {
    type: String,
    default: ''
  },
  checkInTime: {
    type: Date,
    default: null
  },
  checkOutTime: {
    type: Date,
    default: null
  }
}, { timestamps: true });

// Index for date-based queries
attendanceSchema.index({ date: 1, user: 1 }, { unique: true });

// Index for geospatial queries
attendanceSchema.index({ location: '2dsphere' });

const Attendance = mongoose.model('Attendance', attendanceSchema);

module.exports = Attendance;