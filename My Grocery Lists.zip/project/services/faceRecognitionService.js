const tf = require('@tensorflow/tfjs-node');
const faceapi = require('face-api.js');
const canvas = require('canvas');
const sharp = require('sharp');
const path = require('path');
const fs = require('fs').promises;
const { logger } = require('../server');

// Patch nodejs canvas
const { Canvas, Image, ImageData } = canvas;
faceapi.env.monkeyPatch({ Canvas, Image, ImageData });

class FaceRecognitionService {
  constructor() {
    this.initialized = false;
    this.model = null;
    this.faceDetector = null;
    this.faceMatcher = null;
    this.modelPath = path.join(__dirname, '../models/weights');
  }

  async initialize() {
    try {
      if (this.initialized) return true;

      // Load face-api.js models
      await Promise.all([
        faceapi.nets.ssdMobilenetv1.loadFromDisk(this.modelPath),
        faceapi.nets.faceLandmark68Net.loadFromDisk(this.modelPath),
        faceapi.nets.faceRecognitionNet.loadFromDisk(this.modelPath),
        faceapi.nets.faceExpressionNet.loadFromDisk(this.modelPath)
      ]);

      this.faceDetector = new faceapi.SsdMobilenetv1Options({
        minConfidence: 0.5,
        maxResults: 1
      });

      this.initialized = true;
      logger.info('Face recognition models initialized');
      return true;
    } catch (error) {
      logger.error('Error initializing face recognition:', error);
      return false;
    }
  }

  async trainModel(userId, images) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      const labeledDescriptors = [];
      const descriptors = [];

      // Process each training image
      for (const image of images) {
        const img = await canvas.loadImage(image.buffer);
        const detection = await faceapi
          .detectSingleFace(img, this.faceDetector)
          .withFaceLandmarks()
          .withFaceDescriptor();

        if (detection) {
          descriptors.push(detection.descriptor);
        }
      }

      if (descriptors.length === 0) {
        throw new Error('No faces detected in training images');
      }

      // Create labeled descriptors
      labeledDescriptors.push(
        new faceapi.LabeledFaceDescriptors(userId, descriptors)
      );

      // Save descriptors
      const saveDir = path.join(this.modelPath, 'descriptors');
      await fs.mkdir(saveDir, { recursive: true });
      await fs.writeFile(
        path.join(saveDir, `${userId}.json`),
        JSON.stringify(descriptors)
      );

      // Update face matcher
      this.faceMatcher = new faceapi.FaceMatcher(labeledDescriptors);

      return true;
    } catch (error) {
      logger.error('Error training model:', error);
      throw error;
    }
  }

  async detectFace(imageBuffer) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      // Preprocess image
      const processedBuffer = await sharp(imageBuffer)
        .resize(640, 480, { fit: 'inside' })
        .toBuffer();

      const img = await canvas.loadImage(processedBuffer);
      
      // Detect face
      const detection = await faceapi
        .detectSingleFace(img, this.faceDetector)
        .withFaceLandmarks()
        .withFaceDescriptor();

      if (!detection) {
        return null;
      }

      return {
        descriptor: detection.descriptor,
        landmarks: detection.landmarks,
        detection: detection.detection
      };
    } catch (error) {
      logger.error('Error detecting face:', error);
      return null;
    }
  }

  async verifyFace(imageBuffer, userId) {
    try {
      const faceData = await this.detectFace(imageBuffer);
      
      if (!faceData) {
        return { matched: false, error: 'No face detected' };
      }

      // Load user's face descriptors
      const descriptorsPath = path.join(this.modelPath, 'descriptors', `${userId}.json`);
      const descriptors = JSON.parse(await fs.readFile(descriptorsPath, 'utf-8'));

      const labeledDescriptors = [
        new faceapi.LabeledFaceDescriptors(userId, descriptors)
      ];

      const faceMatcher = new faceapi.FaceMatcher(labeledDescriptors, 0.6);
      const match = faceMatcher.findBestMatch(faceData.descriptor);

      return {
        matched: match.label === userId,
        distance: match.distance,
        detection: faceData.detection
      };
    } catch (error) {
      logger.error('Error verifying face:', error);
      return { matched: false, error: 'Verification failed' };
    }
  }

  async detectMask(imageBuffer) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      const img = await canvas.loadImage(imageBuffer);
      
      // Detect face and expressions
      const detection = await faceapi
        .detectSingleFace(img, this.faceDetector)
        .withFaceLandmarks()
        .withFaceExpressions();

      if (!detection) {
        return { hasMask: false, confidence: 0 };
      }

      // Use face landmarks and expressions to estimate mask presence
      const mouthLandmarks = detection.landmarks.getMouth();
      const noseLandmarks = detection.landmarks.getNose();

      // Calculate visibility scores
      const mouthVisibility = this.calculateVisibilityScore(mouthLandmarks, img);
      const noseVisibility = this.calculateVisibilityScore(noseLandmarks, img);

      // If both mouth and nose are poorly visible, likely wearing a mask
      const hasMask = mouthVisibility < 0.3 && noseVisibility < 0.3;
      const confidence = 1 - ((mouthVisibility + noseVisibility) / 2);

      return { hasMask, confidence };
    } catch (error) {
      logger.error('Error detecting mask:', error);
      return { hasMask: false, confidence: 0 };
    }
  }

  calculateVisibilityScore(landmarks, image) {
    try {
      // Calculate average pixel intensity around landmarks
      const ctx = canvas.createCanvas(image.width, image.height).getContext('2d');
      ctx.drawImage(image, 0, 0);

      let totalIntensity = 0;
      landmarks.forEach(point => {
        const imageData = ctx.getImageData(point.x - 2, point.y - 2, 5, 5);
        const pixels = imageData.data;
        
        // Calculate average intensity of the 5x5 pixel area
        let intensity = 0;
        for (let i = 0; i < pixels.length; i += 4) {
          intensity += (pixels[i] + pixels[i + 1] + pixels[i + 2]) / 3;
        }
        totalIntensity += intensity / (25 * 255); // Normalize to 0-1
      });

      return totalIntensity / landmarks.length;
    } catch (error) {
      logger.error('Error calculating visibility score:', error);
      return 1; // Return max visibility on error
    }
  }

  async detectLiveness(imageBuffers) {
    try {
      if (!this.initialized) {
        await this.initialize();
      }

      if (imageBuffers.length < 2) {
        return { isLive: false, confidence: 0 };
      }

      let blinkDetected = false;
      let previousEAR = null;
      
      // Process each frame
      for (const buffer of imageBuffers) {
        const img = await canvas.loadImage(buffer);
        const detection = await faceapi
          .detectSingleFace(img, this.faceDetector)
          .withFaceLandmarks();

        if (!detection) continue;

        const landmarks = detection.landmarks;
        const leftEye = landmarks.getLeftEye();
        const rightEye = landmarks.getRightEye();

        // Calculate Eye Aspect Ratio (EAR)
        const leftEAR = this.calculateEAR(leftEye);
        const rightEAR = this.calculateEAR(rightEye);
        const ear = (leftEAR + rightEAR) / 2;

        if (previousEAR !== null) {
          // Detect blink
          if (previousEAR > 0.3 && ear < 0.2 && previousEAR - ear > 0.1) {
            blinkDetected = true;
            break;
          }
        }

        previousEAR = ear;
      }

      return {
        isLive: blinkDetected,
        confidence: blinkDetected ? 0.85 : 0.15
      };
    } catch (error) {
      logger.error('Error detecting liveness:', error);
      return { isLive: false, confidence: 0 };
    }
  }

  calculateEAR(eyePoints) {
    try {
      // Get vertical distances
      const p2_p6 = this.euclideanDistance(eyePoints[1], eyePoints[5]);
      const p3_p5 = this.euclideanDistance(eyePoints[2], eyePoints[4]);
      
      // Get horizontal distance
      const p1_p4 = this.euclideanDistance(eyePoints[0], eyePoints[3]);
      
      // Calculate EAR
      return (p2_p6 + p3_p5) / (2.0 * p1_p4);
    } catch (error) {
      logger.error('Error calculating EAR:', error);
      return 1; // Return max EAR on error
    }
  }

  euclideanDistance(point1, point2) {
    return Math.sqrt(
      Math.pow(point2.x - point1.x, 2) + Math.pow(point2.y - point1.y, 2)
    );
  }
}

module.exports = new FaceRecognitionService();