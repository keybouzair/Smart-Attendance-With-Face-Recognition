const nodemailer = require('nodemailer');
const User = require('../models/User');
const Notification = require('../models/Notification');
const { logger } = require('../server');

class NotificationService {
  constructor() {
    // Initialize email transporter
    this.transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
      }
    });
  }
  
  /**
   * Send an email notification
   * @param {String} to - Recipient email
   * @param {String} subject - Email subject
   * @param {String} message - Email message (HTML)
   * @returns {Promise<Boolean>} - True if sent successfully, false otherwise
   */
  async sendEmail(to, subject, message) {
    try {
      const mailOptions = {
        from: process.env.EMAIL_USER,
        to,
        subject,
        html: message
      };
      
      await this.transporter.sendMail(mailOptions);
      logger.info(`Email sent to ${to}`);
      return true;
    } catch (error) {
      logger.error('Email sending error:', error);
      return false;
    }
  }
  
  /**
   * Create and send a notification
   * @param {String} userId - Recipient user ID
   * @param {String} title - Notification title
   * @param {String} message - Notification message
   * @param {String} type - Notification type (email, sms, system)
   * @param {Boolean} sendEmail - Whether to also send email
   * @returns {Promise<Object>} - Created notification
   */
  async createNotification(userId, title, message, type = 'system', sendEmail = false) {
    try {
      // Create notification
      const notification = new Notification({
        recipient: userId,
        title,
        message,
        type,
        status: 'sent'
      });
      
      await notification.save();
      
      // Send email if requested
      if (sendEmail) {
        const user = await User.findById(userId);
        
        if (user && user.email) {
          const emailSent = await this.sendEmail(
            user.email,
            title,
            `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #0A84FF;">${title}</h2>
              <p>${message}</p>
              <p style="color: #666; font-size: 12px;">
                This is an automated message from the Attendance System.
              </p>
            </div>`
          );
          
          if (!emailSent) {
            notification.status = 'failed';
            await notification.save();
          }
        }
      }
      
      return notification;
    } catch (error) {
      logger.error('Create notification error:', error);
      throw error;
    }
  }
  
  /**
   * Send absence notification to parent
   * @param {String} studentId - Student ID
   * @param {Date} date - Absence date
   * @returns {Promise<Boolean>} - True if sent successfully, false otherwise
   */
  async sendAbsenceNotification(studentId, date) {
    try {
      const student = await User.findById(studentId);
      
      if (!student || !student.parentEmail) {
        return false;
      }
      
      const dateStr = date.toLocaleDateString();
      
      // Create notification
      await this.createNotification(
        student._id,
        'Absence Notification',
        `You were marked absent on ${dateStr}.`,
        'system',
        false
      );
      
      // Send email to parent
      const emailSent = await this.sendEmail(
        student.parentEmail,
        `Absence Notification for ${student.name}`,
        `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0A84FF;">Absence Notification</h2>
          <p>Dear Parent/Guardian,</p>
          <p>This is to inform you that ${student.name} was marked absent on ${dateStr}.</p>
          <p>If you believe this is an error, please contact the school administration.</p>
          <p style="color: #666; font-size: 12px;">
            This is an automated message from the Attendance System.
          </p>
        </div>`
      );
      
      return emailSent;
    } catch (error) {
      logger.error('Send absence notification error:', error);
      return false;
    }
  }
  
  /**
   * Send notifications to all users matching a query
   * @param {Object} query - User query
   * @param {String} title - Notification title
   * @param {String} message - Notification message
   * @param {Boolean} sendEmail - Whether to also send email
   * @returns {Promise<Number>} - Number of notifications sent
   */
  async sendBulkNotifications(query, title, message, sendEmail = false) {
    try {
      const users = await User.find(query);
      let count = 0;
      
      for (const user of users) {
        await this.createNotification(
          user._id,
          title,
          message,
          'system',
          sendEmail
        );
        
        count++;
      }
      
      return count;
    } catch (error) {
      logger.error('Send bulk notifications error:', error);
      throw error;
    }
  }
}

module.exports = new NotificationService();